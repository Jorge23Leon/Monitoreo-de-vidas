package com.example.myapplication.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.myapplication.local.entities.LocalPlotEntity

@Dao
interface LocalPlotDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPlot(plot: LocalPlotEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPlots(plots: List<LocalPlotEntity>)

    @Update
    suspend fun updatePlot(plot: LocalPlotEntity)

    @Delete
    suspend fun deletePlot(plot: LocalPlotEntity)

    @Query("SELECT * FROM local_plots ORDER BY idLocalPlot ASC")
    suspend fun getAllPlots(): List<LocalPlotEntity>

    @Query("SELECT * FROM local_plots WHERE idLocalPlot = :idLocalPlot LIMIT 1")
    suspend fun getPlotById(idLocalPlot: Long): LocalPlotEntity?

    @Query("SELECT * FROM local_plots WHERE idLocalRanch = :idLocalRanch ORDER BY name ASC")
    suspend fun getPlotsByRanch(idLocalRanch: Long): List<LocalPlotEntity>

    @Query("SELECT * FROM local_plots WHERE code = :code LIMIT 1")
    suspend fun getPlotByCode(code: String): LocalPlotEntity?

    @Query("SELECT COUNT(*) FROM local_plots")
    suspend fun countPlots(): Int

    @Query("DELETE FROM local_plots")
    suspend fun deleteAllPlots()

    @Query("""
        SELECT *
        FROM local_plots
        WHERE idLocalRanch = :idRanch
        ORDER BY name ASC
    """)
    suspend fun getParcelasByRancho(idRanch: Long): List<LocalPlotEntity>

    @Query("""
        SELECT *
        FROM local_plots
        WHERE assigned_user_id = :idUser
        ORDER BY name ASC
    """)
    suspend fun getParcelasAsignadasAUsuario(idUser: Long): List<LocalPlotEntity>

    @Query("""
        SELECT *
        FROM local_plots
        WHERE idLocalRanch = :idRanch
          AND assigned_user_id = :idUser
        ORDER BY name ASC
    """)
    suspend fun getParcelasByRanchoAndUser(
        idRanch: Long,
        idUser: Long
    ): List<LocalPlotEntity>

    @Query("""
        SELECT *
        FROM local_plots
        WHERE idLocalPlot IN (:ids)
    """)
    suspend fun getParcelasByIds(ids: List<Long>): List<LocalPlotEntity>
    @Query("SELECT * FROM local_plots WHERE ext_id = :extId LIMIT 1")
    suspend fun getPlotByExtId(extId: String): LocalPlotEntity?

    @Query("""
    SELECT *
    FROM local_plots
    WHERE idLocalRanch = :idLocalRanch
      AND code = :code
    LIMIT 1
""")
    suspend fun getPlotByCodeAndRanch(
        idLocalRanch: Long,
        code: String
    ): LocalPlotEntity?
}
